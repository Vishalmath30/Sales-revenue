CREATE DATABASE DataAnalystPortfolio;
GO
USE DataAnalystPortfolio;
GO
CREATE TABLE Sales (
 Order_ID VARCHAR(20), Order_Date DATE, Customer_ID VARCHAR(20),
 Customer_Name VARCHAR(100), Product VARCHAR(100), Category VARCHAR(50),
 Region VARCHAR(50), Quantity INT, Sales DECIMAL(12,2),
 Discount DECIMAL(5,2), Profit DECIMAL(12,2)
);
GO
SELECT SUM(Sales) Total_Sales, SUM(Profit) Total_Profit,
 COUNT(DISTINCT Order_ID) Total_Orders FROM Sales;
SELECT Category, SUM(Sales) Total_Sales, SUM(Profit) Total_Profit
FROM Sales GROUP BY Category ORDER BY Total_Sales DESC;
SELECT Region, SUM(Sales) Total_Sales, SUM(Profit) Total_Profit
FROM Sales GROUP BY Region ORDER BY Total_Sales DESC;
SELECT TOP 10 Product, SUM(Sales) Total_Sales, SUM(Profit) Total_Profit
FROM Sales GROUP BY Product ORDER BY Total_Sales DESC;
