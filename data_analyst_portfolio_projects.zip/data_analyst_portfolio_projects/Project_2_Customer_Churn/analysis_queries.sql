USE DataAnalystPortfolio;
GO
CREATE TABLE Customers (
 Customer_ID VARCHAR(20), Gender VARCHAR(20), Age INT, Tenure INT,
 Contract_Type VARCHAR(50), Monthly_Charges DECIMAL(10,2),
 Total_Charges DECIMAL(12,2), Internet_Service VARCHAR(50),
 Payment_Method VARCHAR(50), Support_Service VARCHAR(20), Churn VARCHAR(10)
);
GO
SELECT COUNT(*) Total_Customers,
 SUM(CASE WHEN Churn='Yes' THEN 1 ELSE 0 END) Churned_Customers,
 100.0*SUM(CASE WHEN Churn='Yes' THEN 1 ELSE 0 END)/COUNT(*) Churn_Rate
FROM Customers;
SELECT Contract_Type, COUNT(*) Total_Customers,
 SUM(CASE WHEN Churn='Yes' THEN 1 ELSE 0 END) Churned
FROM Customers GROUP BY Contract_Type;
SELECT Internet_Service, COUNT(*) Customers,
 SUM(CASE WHEN Churn='Yes' THEN 1 ELSE 0 END) Churned
FROM Customers GROUP BY Internet_Service;
