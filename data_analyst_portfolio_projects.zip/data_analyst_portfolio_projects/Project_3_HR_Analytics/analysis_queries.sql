USE DataAnalystPortfolio;
GO
CREATE TABLE Employees (
 Employee_ID INT, Age INT, Gender VARCHAR(20), Department VARCHAR(50),
 Job_Role VARCHAR(100), Education VARCHAR(50), Years_At_Company INT,
 Years_Experience INT, Monthly_Salary DECIMAL(12,2),
 Job_Satisfaction INT, Work_Life_Balance INT, Overtime VARCHAR(10),
 Attrition VARCHAR(10)
);
GO
SELECT COUNT(*) Total_Employees,
 SUM(CASE WHEN Attrition='Yes' THEN 1 ELSE 0 END) Attrition_Count,
 100.0*SUM(CASE WHEN Attrition='Yes' THEN 1 ELSE 0 END)/COUNT(*) Attrition_Rate
FROM Employees;
SELECT Department, COUNT(*) Employees,
 SUM(CASE WHEN Attrition='Yes' THEN 1 ELSE 0 END) Attrition_Count
FROM Employees GROUP BY Department ORDER BY Attrition_Count DESC;
SELECT Job_Role, COUNT(*) Employees,
 SUM(CASE WHEN Attrition='Yes' THEN 1 ELSE 0 END) Attrition_Count
FROM Employees GROUP BY Job_Role ORDER BY Attrition_Count DESC;
SELECT Overtime, COUNT(*) Employees,
 SUM(CASE WHEN Attrition='Yes' THEN 1 ELSE 0 END) Attrition_Count
FROM Employees GROUP BY Overtime;
