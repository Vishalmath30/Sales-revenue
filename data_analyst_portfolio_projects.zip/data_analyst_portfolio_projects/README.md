# Data Analyst Portfolio Projects

Three end-to-end practice projects:
1. Sales & Revenue Analysis
2. Customer Churn & Retention Analysis
3. HR Employee Analytics

Workflow: CSV → Excel cleaning → SQL Server → SQL analysis → Power BI → business insights.

The included datasets are synthetic practice data generated for portfolio use.
